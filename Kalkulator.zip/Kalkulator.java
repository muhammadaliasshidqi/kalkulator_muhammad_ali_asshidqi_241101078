/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kalkulator;

/**
 *
 * @author User-17
 */
public class Kalkulator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       penjumlahan jumlah = new penjumlahan (20,30);
       pengurangan kurang = new pengurangan (70,40);
       perkalian kali = new perkalian (20,5);
       pembagian bagi = new pembagian (100,2);
       modulus sisa_bagi = new modulus (25,2);
       kuadrat Kuadrat = new kuadrat (8);
       pengakaran akar = new pengakaran (100);
    }
    
    private static class penjumlahan {
        public penjumlahan (int a, int b) {
            System.out.println("hasil dari penjumlahan =");
            int c;
            c = a+b;
            System.out.println(c);
        }
    }
    
    private static class pengurangan {
        public pengurangan (int a, int b) {
            System.out.println("hasil dari pengurangan =");
            int c;
            c = a-b;
            System.out.println(c);
        }
    }
    
    private static class perkalian {
        public perkalian (int a, int b) {
            System.out.println("hasil dari perkalian =");
            int c;
            c = a*b;
            System.out.println(c);
        }
    }
    
    private static class pembagian {
        public pembagian (int a,int b) {
            System.out.println("hasil dari pembagian =");
            int c;
            c = a/b;
            System.out.println(c);
        }
    }
    
     private static class modulus {
        public modulus (int a,int b) {
            System.out.println("hasil dari modulus =");
            int c;
            c = a%b;
            System.out.println(c);
        }
    }
    
      private static class kuadrat {
        public kuadrat (int a) {
            System.out.println("hasil dari kuadrat =");
            int c;
            c = a*a;
            System.out.println(c);
        }
    }
      private static class pengakaran {
          public pengakaran (int a) {
              System.out.println("hasil dari akar =");
              
              double b = Math.sqrt(a);
              System.out.println(b);
          }
      }
}
